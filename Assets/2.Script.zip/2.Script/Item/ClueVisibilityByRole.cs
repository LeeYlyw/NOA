using System.Collections;
using UnityEngine;

public class ClueVisibilityByRole : MonoBehaviour
{
    [Header("Target")]
    [Tooltip("����θ� �� ������Ʈ�� �ڽ� Renderer�� �ڵ����� ã���ϴ�.")]
    public GameObject visualRoot;

    [Header("Collider Option")]
    [Tooltip("Detector Ŭ���̾�Ʈ���� �ܼ� Collider�� ���� ȹ�� Ʈ���� ��ü�� �����ϴ�.")]
    public bool disableColliderForDetector = true;

    private Renderer[] renderers;
    private Collider[] colliders;

    private void Awake()
    {
        CacheComponents();
    }

    private void Start()
    {
        StartCoroutine(ApplyVisibilityWhenReady());
    }

    private void CacheComponents()
    {
        GameObject target = visualRoot != null ? visualRoot : gameObject;

        renderers = target.GetComponentsInChildren<Renderer>(true);
        colliders = GetComponentsInChildren<Collider>(true);
    }

    private IEnumerator ApplyVisibilityWhenReady()
    {
        while (NetworkClient.Instance == null || NetworkClient.Instance.localPlayerTransform == null)
        {
            yield return null;
        }

        PlayerRoleSetup roleSetup =
            NetworkClient.Instance.localPlayerTransform.GetComponent<PlayerRoleSetup>();

        if (roleSetup == null)
        {
            Debug.LogWarning("ClueVisibilityByRole: ���� �÷��̾�� PlayerRoleSetup�� ã�� ���߽��ϴ�.");
            yield break;
        }

        bool isExplorer = roleSetup.IsExplorer;

        SetVisible(isExplorer);

        if (disableColliderForDetector)
        {
            SetColliderEnabled(isExplorer);
        }

        Debug.Log(
            "ClueVisibilityByRole ���� �Ϸ� / Object: " + gameObject.name +
            " / Explorer: " + isExplorer
        );
    }

    private void SetVisible(bool visible)
    {
        if (renderers == null || renderers.Length == 0)
            CacheComponents();

        foreach (Renderer renderer in renderers)
        {
            if (renderer != null)
                renderer.enabled = visible;
        }
    }

    private void SetColliderEnabled(bool enabled)
    {
        if (colliders == null || colliders.Length == 0)
            CacheComponents();

        foreach (Collider col in colliders)
        {
            if (col != null)
                col.enabled = enabled;
        }
    }
}