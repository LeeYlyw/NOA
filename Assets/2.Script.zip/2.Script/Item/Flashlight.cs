using UnityEngine;

public class Flashlight : MonoBehaviour
{
    [SerializeField] private Light flashlightLight; // ����� �޸� Spot Light ������Ʈ ����
    private bool isLightOn = false;

    public void ToggleLight()
    {
        isLightOn = !isLightOn;
        if (flashlightLight != null)
        {
            flashlightLight.enabled = isLightOn;
        }
    }

    public void TurnOn()
    {
        isLightOn = true;
        if (flashlightLight != null) flashlightLight.enabled = true;
    }
}