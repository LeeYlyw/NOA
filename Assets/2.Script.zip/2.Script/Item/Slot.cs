using UnityEngine;
using UnityEngine.UI;

public class Slot : MonoBehaviour
{
    public ItemData item;
    public Image iconImage;

    public void SetItem(ItemData newItem)
    {
        item = newItem;
        iconImage.sprite = item.icon;
        iconImage.enabled = true;
    }

    public void ClearSlot()
    {
        item = null;
        iconImage.sprite = null;
        iconImage.enabled = false;
    }

    public void OnClickSlot()
    {
        if (item == null)
            return;

        if (item.type == ItemData.ItemType.Heal)
        {
            UseHealItem();
        }
        else if (item.type == ItemData.ItemType.Stealth)
        {
            UseStealthItem();
        }
        else if (item.type == ItemData.ItemType.Teleport)
        {
            UseTeleportItem();
        }
        else if (item.type == ItemData.ItemType.Resurrection)
        {
            UseResurrectionItem();
        }
    }

    private Transform GetLocalPlayer()
    {
        if (NetworkClient.Instance == null)
        {
            Debug.LogError("NetworkClient.Instance�� �����ϴ�.");
            return null;
        }

        if (NetworkClient.Instance.localPlayerTransform == null)
        {
            Debug.LogError("NetworkClient.localPlayerTransform�� �������� �ʾҽ��ϴ�.");
            return null;
        }

        return NetworkClient.Instance.localPlayerTransform;
    }

    private Transform GetRemotePlayer()
    {
        if (NetworkClient.Instance == null)
        {
            Debug.LogError("NetworkClient.Instance�� �����ϴ�.");
            return null;
        }

        if (NetworkClient.Instance.remotePlayerTransform == null)
        {
            Debug.LogError("NetworkClient.remotePlayerTransform�� �������� �ʾҽ��ϴ�.");
            return null;
        }

        return NetworkClient.Instance.remotePlayerTransform;
    }

    private void UseHealItem()
    {
        Transform localPlayer = GetLocalPlayer();
        if (localPlayer == null)
            return;

        PlayerController player = localPlayer.GetComponent<PlayerController>();
        if (player == null)
        {
            Debug.LogError("���� �÷��̾ PlayerController�� �����ϴ�.");
            return;
        }

        if (ItemEffectManager.Instance != null)
        {
            ItemEffectManager.Instance.PlayHealEffect(localPlayer.position);
        }

        player.HealToFull();
        Debug.Log("ȸ�� ������ ��� �Ϸ�");
        ClearSlot();
    }

    private void UseStealthItem()
    {
        Transform localPlayer = GetLocalPlayer();
        if (localPlayer == null)
            return;

        PlayerStealth stealth = localPlayer.GetComponent<PlayerStealth>();
        if (stealth == null)
        {
            Debug.LogError("���� �÷��̾ PlayerStealth�� �����ϴ�.");
            return;
        }

        if (ItemEffectManager.Instance != null)
        {
            ItemEffectManager.Instance.PlayStealthEffect(localPlayer.position);
        }

        stealth.ActivateStealth();
        Debug.Log("���� ������ ��� �Ϸ�");
        ClearSlot();
    }

    private void UseTeleportItem()
    {
        Transform localPlayer = GetLocalPlayer();
        if (localPlayer == null)
            return;

        GameObject targetPoint = GameObject.FindGameObjectWithTag("TeleportPoint");
        if (targetPoint == null)
        {
            Debug.LogError("�ʿ� TeleportPoint �±׸� ���� ������Ʈ�� �����ϴ�.");
            return;
        }

        CharacterController cc = localPlayer.GetComponent<CharacterController>();

        Vector3 originPos = localPlayer.position;
        if (ItemEffectManager.Instance != null)
        {
            ItemEffectManager.Instance.PlayTeleportEffect(originPos);
        }

        if (cc != null)
            cc.enabled = false;

        localPlayer.position = targetPoint.transform.position;

        if (cc != null)
            cc.enabled = true;

        if (ItemEffectManager.Instance != null)
        {
            ItemEffectManager.Instance.PlayTeleportEffect(targetPoint.transform.position);
        }

        Debug.Log("�ڷ���Ʈ ������ ��� �Ϸ�");
        ClearSlot();
    }

    private void UseResurrectionItem()
    {
        Transform remotePlayer = GetRemotePlayer();
        if (remotePlayer == null)
            return;

        PlayerController teammateController = remotePlayer.GetComponent<PlayerController>();
        if (teammateController == null)
        {
            Debug.LogError("���� �÷��̾ PlayerController�� �����ϴ�.");
            return;
        }

        if (!teammateController.IsDead())
        {
            Debug.Log("���ᰡ ����־ ��Ȱ �������� ����� �� �����ϴ�.");
            return;
        }

        if (ItemEffectManager.Instance != null)
        {
            ItemEffectManager.Instance.PlayResurrectionEffect(remotePlayer.position);
        }

        int targetPlayerId = NetworkClient.Instance.playerId == 1 ? 2 : 1;

        teammateController.Revive();
        NetworkClient.Instance.SendPlayerRevive(targetPlayerId);

        Debug.Log("���� ��Ȱ ������ ��� �Ϸ� / ��� PlayerId: " + targetPlayerId);
        ClearSlot();
    }
}