using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class RoomData
{
    public GameObject prefab;
    public int sizeX = 1;
    public int sizeZ = 1;
}

public class MapGenerator : MonoBehaviour
{
    [Header("�� �԰� ����")]
    public int mapSize = 20;
    public float tileSize = 10f;

    [Header("���� ��� ������ (�ܸ� I��, �𼭸� L��)")]
    public GameObject prefabI;    // ���� (�ܸ� �� 1��)
    public GameObject prefabL;    // ���� (�ڳ� ��)

    [Header("��ġ�� �� ���")]
    public List<RoomData> roomsToSpawn;

    // 0: �����, 1: ����, 2: �� ��ü, 3: �� ���Թ�(Door)
    private int[,] map;
    private List<Vector2Int> roomDoors = new List<Vector2Int>();

    void Start()
    {
        GenerateMap();
    }

    void GenerateMap()
    {
        for (int i = transform.childCount - 1; i >= 0; i--)
        {
            DestroyImmediate(transform.GetChild(i).gameObject);
        }

        map = new int[mapSize, mapSize];
        roomDoors.Clear();

        PlaceRooms();
        BuildNonLinearMaze();
        SpawnPrefabsSafely();  // <- �� �κ��� ������ ���� �ۼ��Ǿ����ϴ�.
    }

    void PlaceRooms()
    {
        float startOffset = -(mapSize * tileSize) / 2f + (tileSize / 2f);

        for (int i = 0; i < roomsToSpawn.Count; i++)
        {
            var room = roomsToSpawn[i];
            if (room.prefab == null) continue;

            bool placed = false;
            int attempts = 0;

            int maxX = mapSize - room.sizeX - 1;
            int maxZ = mapSize - room.sizeZ - 1;

            while (!placed && attempts < 500)
            {
                int rx = Random.Range(1, maxX);
                int rz = Random.Range(2, maxZ);

                if (IsAreaClear(rx, rz, room.sizeX, room.sizeZ))
                {
                    for (int x = rx; x < rx + room.sizeX; x++)
                    {
                        for (int z = rz; z < rz + room.sizeZ; z++)
                        {
                            map[x, z] = 2;
                        }
                    }

                    int doorX = rx + (room.sizeX / 2);
                    int doorZ = rz - 1;
                    map[doorX, doorZ] = 3;
                    roomDoors.Add(new Vector2Int(doorX, doorZ));

                    float posX = startOffset + (rx * tileSize) + ((room.sizeX - 1) * tileSize / 2f);
                    float posZ = startOffset + (rz * tileSize) + ((room.sizeZ - 1) * tileSize / 2f);
                    Instantiate(room.prefab, new Vector3(posX, 0, posZ), Quaternion.identity, transform);

                    placed = true;
                }
                attempts++;
            }
        }
    }

    bool IsAreaClear(int startX, int startZ, int sizeX, int sizeZ)
    {
        for (int x = startX - 1; x <= startX + sizeX; x++)
        {
            for (int z = startZ - 1; z <= startZ + sizeZ; z++)
            {
                if (x < 0 || x >= mapSize || z < 0 || z >= mapSize) return false;
                if (map[x, z] != 0) return false;
            }
        }
        return true;
    }

    void BuildNonLinearMaze()
    {
        if (roomDoors.Count < 2) return;

        for (int i = 0; i < roomDoors.Count; i++)
        {
            Vector2Int start = roomDoors[i];
            Vector2Int end = roomDoors[(i + 1) % roomDoors.Count];
            ConnectWithRandomTurn(start, end);
        }

        Vector2Int[] borderPoints = new Vector2Int[]
        {
            new Vector2Int(0, Random.Range(1, mapSize - 1)),
            new Vector2Int(mapSize - 1, Random.Range(1, mapSize - 1)),
            new Vector2Int(Random.Range(1, mapSize - 1), 0),
            new Vector2Int(Random.Range(1, mapSize - 1), mapSize - 1)
        };

        foreach (var border in borderPoints)
        {
            Vector2Int nearest = FindNearestCorridor(border);
            if (nearest.x != -1)
            {
                ConnectWithRandomTurn(nearest, border);
            }
        }

        GrowMazeBranches(15);
    }

    void ConnectWithRandomTurn(Vector2Int start, Vector2Int end)
    {
        Vector2Int mid = new Vector2Int(
            Random.value > 0.5f ? start.x : end.x,
            Random.value > 0.5f ? end.y : start.y
        );

        mid.x = Mathf.Clamp(mid.x, 0, mapSize - 1);
        mid.y = Mathf.Clamp(mid.y, 0, mapSize - 1);

        BFSConnect(start, mid);
        BFSConnect(mid, end);
    }

    void GrowMazeBranches(int branchCount)
    {
        Vector2Int[] dirs = { Vector2Int.up, Vector2Int.down, Vector2Int.left, Vector2Int.right };

        for (int i = 0; i < branchCount; i++)
        {
            List<Vector2Int> corridors = new List<Vector2Int>();
            for (int x = 0; x < mapSize; x++)
            {
                for (int z = 0; z < mapSize; z++)
                {
                    if (map[x, z] == 1) corridors.Add(new Vector2Int(x, z));
                }
            }

            if (corridors.Count == 0) break;

            Vector2Int curr = corridors[Random.Range(0, corridors.Count)];
            int steps = Random.Range(3, 7);

            for (int s = 0; s < steps; s++)
            {
                Vector2Int dir = dirs[Random.Range(0, 4)];
                Vector2Int next = curr + dir;

                if (next.x >= 0 && next.x < mapSize && next.y >= 0 && next.y < mapSize)
                {
                    if (map[next.x, next.y] == 0)
                    {
                        map[next.x, next.y] = 1;
                        curr = next;
                    }
                    else break;
                }
                else break;
            }
        }
    }

    Vector2Int FindNearestCorridor(Vector2Int point)
    {
        Vector2Int nearest = new Vector2Int(-1, -1);
        float minDist = float.MaxValue;

        for (int x = 0; x < mapSize; x++)
        {
            for (int z = 0; z < mapSize; z++)
            {
                if (map[x, z] == 1)
                {
                    float dist = Vector2Int.Distance(point, new Vector2Int(x, z));
                    if (dist < minDist)
                    {
                        minDist = dist;
                        nearest = new Vector2Int(x, z);
                    }
                }
            }
        }
        return nearest;
    }

    void BFSConnect(Vector2Int start, Vector2Int end)
    {
        Queue<Vector2Int> queue = new Queue<Vector2Int>();
        Dictionary<Vector2Int, Vector2Int> cameFrom = new Dictionary<Vector2Int, Vector2Int>();

        queue.Enqueue(start);
        cameFrom[start] = start;

        Vector2Int[] dirs = { Vector2Int.up, Vector2Int.down, Vector2Int.left, Vector2Int.right };

        while (queue.Count > 0)
        {
            Vector2Int curr = queue.Dequeue();
            if (curr == end) break;

            foreach (var dir in dirs)
            {
                Vector2Int next = curr + dir;
                if (next.x >= 0 && next.x < mapSize && next.y >= 0 && next.y < mapSize)
                {
                    if (!cameFrom.ContainsKey(next))
                    {
                        if (map[next.x, next.y] != 2)
                        {
                            queue.Enqueue(next);
                            cameFrom[next] = curr;
                        }
                    }
                }
            }
        }

        if (cameFrom.ContainsKey(end))
        {
            Vector2Int curr = end;
            while (curr != start)
            {
                if (map[curr.x, curr.y] == 0) map[curr.x, curr.y] = 1;
                curr = cameFrom[curr];
            }
        }
    }

    // =========================================================
    // ���⼭���� ������ �ٲ� �� ���� �����Դϴ�.
    // =========================================================

    void SpawnPrefabsSafely()
    {
        float startOffset = -(mapSize * tileSize) / 2f + (tileSize / 2f);

        for (int x = 0; x < mapSize; x++)
        {
            for (int z = 0; z < mapSize; z++)
            {
                // ���(1)�̰ų� ��(3)�� ������ ���� ���� ����
                if (map[x, z] == 1 || map[x, z] == 3)
                {
                    // �ֺ� 4������ �շ��ִ� '��'���� Ȯ���մϴ�.
                    bool pathTop = IsPath(x, z, x, z + 1);
                    bool pathBottom = IsPath(x, z, x, z - 1);
                    bool pathLeft = IsPath(x, z, x - 1, z);
                    bool pathRight = IsPath(x, z, x + 1, z);

                    // ���� �ƴ϶��(����̳� ���� ��) �� ���⿡ ������ ���� �ľ� �մϴ�.
                    bool wallTop = !pathTop;
                    bool wallBottom = !pathBottom;
                    bool wallLeft = !pathLeft;
                    bool wallRight = !pathRight;

                    Vector3 pos = new Vector3(startOffset + (x * tileSize), 0, startOffset + (z * tileSize));

                    // 1. �ڳ�(L�� ��) �켱 ��ġ (�� ���� ���ÿ� �����ݴϴ�)
                    if (wallTop && wallRight)
                    {
                        Instantiate(prefabL, pos, Quaternion.Euler(0, 0, 0), transform); // ��, �� Ŀ��
                        wallTop = false; wallRight = false;
                    }
                    if (wallRight && wallBottom)
                    {
                        Instantiate(prefabL, pos, Quaternion.Euler(0, 90, 0), transform); // ��, �� Ŀ��
                        wallRight = false; wallBottom = false;
                    }
                    if (wallBottom && wallLeft)
                    {
                        Instantiate(prefabL, pos, Quaternion.Euler(0, 180, 0), transform); // ��, �� Ŀ��
                        wallBottom = false; wallLeft = false;
                    }
                    if (wallLeft && wallTop)
                    {
                        Instantiate(prefabL, pos, Quaternion.Euler(0, 270, 0), transform); // ��, �� Ŀ��
                        wallLeft = false; wallTop = false;
                    }

                    // 2. ���� �ո� ���� I�� ��(�ܸ� ��)�� ���� �� ��ġ�Ͽ� ���� �����ݴϴ�.
                    // (���� ��ζ�� ��/�츦 ���� ���� I�� ���� 2�� �����˴ϴ�!)
                    if (wallTop)
                    {
                        Instantiate(prefabI, pos, Quaternion.Euler(0, 0, 0), transform); // ���� ��
                    }
                    if (wallRight)
                    {
                        Instantiate(prefabI, pos, Quaternion.Euler(0, 90, 0), transform); // ���� ��
                    }
                    if (wallBottom)
                    {
                        Instantiate(prefabI, pos, Quaternion.Euler(0, 180, 0), transform); // ���� ��
                    }
                    if (wallLeft)
                    {
                        Instantiate(prefabI, pos, Quaternion.Euler(0, 270, 0), transform); // ���� ��
                    }
                }
            }
        }
    }

    // Ư�� ��ǥ(nx, nz)�� �� �� �ִ� ������ Ȯ���ϴ� �Լ�
    bool IsPath(int cx, int cz, int nx, int nz)
    {
        // �� ���� ����̹Ƿ� ���� �ľ��� (�� �ƴ� = false)
        if (nx < 0 || nx >= mapSize || nz < 0 || nz >= mapSize) return false;

        int neighbor = map[nx, nz];

        // 1(����)�̰ų� 3(��)�̸� ������ ��
        if (neighbor == 1 || neighbor == 3) return true;

        // 2(��)�� ���: �� �����δ� ħ���ϸ� �� ������, 
        // ���� ���� �� �ִ� ��(cx, cz)�� ��(3)�̶�� ������ ����Ǵ� ���� ����
        if (neighbor == 2 && map[cx, cz] == 3) return true;

        return false;
    }
}