using UnityEngine;
using UnityEngine.AI;

public class MonsterNetworkSetup : MonoBehaviour
{
    [Header("Monster Id")]
    public int monsterId = 1;

    [Header("Components")]
    public NavMeshAgent navMeshAgent;
    public RemoteMonster remoteMonster;
    public MonoBehaviour[] aiScripts;

    void Start()
    {
        // NetworkClient�� offlineMode Ȯ��
        bool isOffline = (NetworkClient.Instance != null && NetworkClient.Instance.offlineMode);

        if (isOffline)
        {
            SetupOfflineMode();
        }
        else
        {
            SetupServerAuthoritativeMode();
        }
    }

    // �̱� �׽�Ʈ ��: ����Ƽ ��ü AI ����
    void SetupOfflineMode()
    {
        if (aiScripts != null)
        {
            foreach (MonoBehaviour ai in aiScripts)
            {
                if (ai != null) ai.enabled = true;
            }
        }

        if (navMeshAgent != null) navMeshAgent.enabled = true;
        if (remoteMonster != null) remoteMonster.enabled = false;

        Debug.Log($"[MonsterNetworkSetup] ���� ID({monsterId}) :: �̱� �׽�Ʈ�� ���� AI ��� Ȱ��ȭ");
    }

    // ��Ƽ�÷��� ��: C++ ���� ������ ���� ���� ���
    void SetupServerAuthoritativeMode()
    {
        if (aiScripts != null)
        {
            foreach (MonoBehaviour ai in aiScripts)
            {
                if (ai != null) ai.enabled = false;
            }
        }

        if (navMeshAgent != null) navMeshAgent.enabled = false;
        if (remoteMonster != null) remoteMonster.enabled = true;

        Debug.Log($"[MonsterNetworkSetup] ���� ID({monsterId}) :: C++ ���� �ֵ� ��� ���� �Ϸ�");
    }

    public void SetupMonster(bool isAuthority)
    {
        SetupServerAuthoritativeMode();
    }
}