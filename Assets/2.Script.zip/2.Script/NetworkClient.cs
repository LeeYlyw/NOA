using System;
using System.Globalization;
using System.IO;
using System.Net.Sockets;
using System.Text;
using UnityEngine;

public class NetworkClient : MonoBehaviour
{
    public static NetworkClient Instance;

    [Header("Network")]
    public string serverIP = "127.0.0.1";
    public int serverPort = 7777;
    public int playerId = 1;

    [Header("Players")]
    public Transform localPlayerTransform;
    public Transform remotePlayerTransform;

    [Header("Auto Setup")]
    public bool autoSetupPlayers = true;
    public GameObject player1Object;
    public GameObject player2Object;

    [Header("Sync")]
    public float sendInterval = 0.1f;

    [Header("Monster Sync")]
    public float monsterSendInterval = 0.1f;

    [Header("Item Sync")]
    public PotionItem[] potionItems;

    private TcpClient client;
    private NetworkStream stream;
    private bool isConnected = false;

    private float sendTimer = 0f;
    private float monsterSendTimer = 0f;

    private string receiveBuffer = "";

    private PlayerController localPlayerController;

    private Vector3 targetRemotePosition;
    private Quaternion targetRemoteRotation;
    private bool hasRemoteState = false;

    private float targetRemoteSpeed;
    private bool targetRemoteIsRunning;
    private bool targetRemoteIsCrouching;

    private MonsterNetworkSetup[] monsterSetups;

    void Awake()
    {
        Instance = this;
        Application.runInBackground = true;
    }

    void Start()
    {
        LoadServerConfig();

        SetupPlayersByPlayerId();
        SetupMonstersByPlayerId();

        monsterSetups = FindObjectsOfType<MonsterNetworkSetup>();
        potionItems = FindObjectsOfType<PotionItem>(true);

        ConnectToServer();

        if (remotePlayerTransform != null)
        {
            targetRemotePosition = remotePlayerTransform.position;
            targetRemoteRotation = remotePlayerTransform.rotation;
        }

        if (localPlayerTransform != null)
        {
            localPlayerController = localPlayerTransform.GetComponent<PlayerController>();
        }
    }

    void Update()
    {
        if (!isConnected || stream == null)
            return;

        SendLocalPlayerTransform();
        SendMonsterTransforms();

        ReceivePackets();

        ApplyRemotePlayerTransform();
    }

    void SetupPlayersByPlayerId()
    {
        if (!autoSetupPlayers)
            return;

        if (player1Object == null || player2Object == null)
        {
            Debug.LogWarning("Player1 Object �Ǵ� Player2 Object�� ��� �ֽ��ϴ�.");
            return;
        }

        bool isPlayer1Local = playerId == 1;
        bool isPlayer2Local = playerId == 2;

        RemotePlayer player1Remote = player1Object.GetComponent<RemotePlayer>();
        RemotePlayer player2Remote = player2Object.GetComponent<RemotePlayer>();

        if (player1Remote != null)
            player1Remote.SetupPlayer(isPlayer1Local);

        if (player2Remote != null)
            player2Remote.SetupPlayer(isPlayer2Local);

        if (playerId == 1)
        {
            localPlayerTransform = player1Object.transform;
            remotePlayerTransform = player2Object.transform;
        }
        else if (playerId == 2)
        {
            localPlayerTransform = player2Object.transform;
            remotePlayerTransform = player1Object.transform;
        }
    }

    void SetupMonstersByPlayerId()
    {
        bool hasMonsterAuthority = playerId == 1;

        MonsterNetworkSetup[] monsters = FindObjectsOfType<MonsterNetworkSetup>();

        foreach (MonsterNetworkSetup monster in monsters)
        {
            monster.SetupMonster(hasMonsterAuthority);
        }

        Debug.Log("���� ���� ���� �Ϸ� / PlayerId: " + playerId + " / Authority: " + hasMonsterAuthority);
    }

    public void SendItemPickup(int itemId)
    {
        string message = string.Format(
            CultureInfo.InvariantCulture,
            "ITEM_PICKUP|{0}|{1}\n",
            itemId,
            playerId
        );

        SendMessageToServer(message, "������ ȹ�� ���� ����");
        Debug.Log("������ ȹ�� ����: " + message);
    }

    public void SendGameClear()
    {
        string msg = "GAME_CLEAR\n";
        SendMessageToServer(msg, "���� Ŭ���� ���� ����");

        Debug.Log("������ GAME_CLEAR ����");
    }

    void ConnectToServer()
    {
        try
        {
            client = new TcpClient();
            client.Connect(serverIP, serverPort);
            stream = client.GetStream();
            isConnected = true;

            Debug.Log("���� ���� ����");
        }
        catch (Exception e)
        {
            Debug.LogError("���� ���� ����: " + e.Message);
        }
    }

    void SendLocalPlayerTransform()
    {
        if (localPlayerTransform == null)
            return;

        sendTimer += Time.deltaTime;

        if (sendTimer < sendInterval)
            return;

        sendTimer = 0f;

        Vector3 pos = localPlayerTransform.position;
        float rotY = localPlayerTransform.eulerAngles.y;

        float animSpeed = 0f;
        bool isRunning = false;
        bool isCrouching = false;

        if (localPlayerController != null)
        {
            animSpeed = localPlayerController.CurrentAnimSpeed;
            isRunning = localPlayerController.IsRunningState;
            isCrouching = localPlayerController.IsCrouchingState;
        }

        string message = string.Format(
            CultureInfo.InvariantCulture,
            "MOVE|{0}|{1:F2}|{2:F2}|{3:F2}|{4:F2}|{5:F2}|{6}|{7}\n",
            playerId,
            pos.x,
            pos.y,
            pos.z,
            rotY,
            animSpeed,
            isRunning ? 1 : 0,
            isCrouching ? 1 : 0
        );

        SendMessageToServer(message, "�÷��̾� ��ġ ���� ����");
    }

    void SendMonsterTransforms()
    {
        if (playerId != 1)
            return;

        if (monsterSetups == null || monsterSetups.Length == 0)
            return;

        monsterSendTimer += Time.deltaTime;

        if (monsterSendTimer < monsterSendInterval)
            return;

        monsterSendTimer = 0f;

        foreach (MonsterNetworkSetup monster in monsterSetups)
        {
            if (monster == null)
                continue;

            Transform monsterTransform = monster.transform;

            Vector3 pos = monsterTransform.position;
            float rotY = monsterTransform.eulerAngles.y;

            float speed = 0f;
            bool isWalk = false;
            bool isAttack = false;

            Animator animator = monster.GetComponent<Animator>();

            if (animator != null)
            {
                speed = animator.GetFloat("Speed");
                isWalk = animator.GetBool("isWalk");
                isAttack = animator.GetBool("isAttack");
            }

            string message = string.Format(
                CultureInfo.InvariantCulture,
                "MONSTER_MOVE|{0}|{1:F2}|{2:F2}|{3:F2}|{4:F2}|{5:F2}|{6}|{7}\n",
                monster.monsterId,
                pos.x,
                pos.y,
                pos.z,
                rotY,
                speed,
                isWalk ? 1 : 0,
                isAttack ? 1 : 0
            );

            SendMessageToServer(message, "���� ��ġ/�ִϸ��̼� ���� ����");
        }
    }

    public void SendPlayerDamage(int targetPlayerId, int damage)
    {
        string message = string.Format(
            CultureInfo.InvariantCulture,
            "PLAYER_DAMAGE|{0}|{1}\n",
            targetPlayerId,
            damage
        );

        SendMessageToServer(message, "�÷��̾� ������ ���� ����");
        Debug.Log("�÷��̾� ������ ����: " + message);

        if (targetPlayerId != playerId)
        {
            ApplyPlayerDamage(targetPlayerId, damage);
        }
    }

    void SendMessageToServer(string message, string errorMessage)
    {
        if (!isConnected || stream == null)
            return;

        byte[] data = Encoding.UTF8.GetBytes(message);

        try
        {
            stream.Write(data, 0, data.Length);
        }
        catch (Exception e)
        {
            Debug.LogError(errorMessage + ": " + e.Message);
            isConnected = false;
        }
    }

    void ReceivePackets()
    {
        try
        {
            while (stream.DataAvailable)
            {
                byte[] buffer = new byte[512];
                int length = stream.Read(buffer, 0, buffer.Length);

                if (length <= 0)
                    break;

                receiveBuffer += Encoding.UTF8.GetString(buffer, 0, length);
            }

            ProcessReceiveBuffer();
        }
        catch (Exception e)
        {
            Debug.LogError("���� ����: " + e.Message);
            isConnected = false;
        }
    }

    void ProcessReceiveBuffer()
    {
        while (true)
        {
            int newlineIndex = receiveBuffer.IndexOf('\n');

            if (newlineIndex < 0)
                break;

            string packet = receiveBuffer.Substring(0, newlineIndex).Trim();
            receiveBuffer = receiveBuffer.Substring(newlineIndex + 1);

            if (string.IsNullOrEmpty(packet))
                continue;

            ProcessPacket(packet);
        }
    }

    void ProcessPacket(string packet)
    {
        Debug.Log("Ŭ�� ���� ��Ŷ: " + packet);

        // GAME_CLEAR�� | ��ȣ�� ���� �ܵ� ��Ŷ�̶�
        // Split �˻纸�� ���� ó���ؾ� ��
        if (packet == "GAME_CLEAR")
        {
            Debug.Log("GAME_CLEAR ���� / ���� �г� ǥ��");

            if (ClueManager.instance != null)
            {
                ClueManager.instance.ShowEnding();
            }
            else
            {
                Debug.LogWarning("ClueManager instance�� ã�� ���߽��ϴ�.");
            }

            return;
        }

        string[] parts = packet.Split('|');

        if (parts.Length < 2)
            return;

        if (parts[0] == "COUNT")
        {
            if (int.TryParse(parts[1], out int count))
            {
                if (LobbyManager.Instance != null)
                    LobbyManager.Instance.SetPlayerCount(count);
            }

            return;
        }

        if (parts[0] == "MOVE")
        {
            ProcessMovePacket(parts, packet);
            return;
        }

        if (parts[0] == "MONSTER_MOVE")
        {
            ProcessMonsterMovePacket(parts, packet);
            return;
        }

        if (parts[0] == "PLAYER_DAMAGE")
        {
            ProcessPlayerDamagePacket(parts, packet);
            return;
        }

        if (parts[0] == "ITEM_PICKUP")
        {
            ProcessItemPickupPacket(parts, packet);
            return;
        }
    }

    void ProcessGameClearPacket()
    {
        Debug.Log("GAME_CLEAR ���� / ���� �г� ǥ��");

        if (ClueManager.instance != null)
        {
            ClueManager.instance.ShowEnding();
        }
        else
        {
            Debug.LogWarning("ClueManager instance�� ã�� ���߽��ϴ�.");
        }
    }

    void ProcessMovePacket(string[] parts, string packet)
    {
        if (parts.Length != 9)
        {
            Debug.LogWarning("MOVE ��Ŷ ������ ���� ����: " + packet);
            return;
        }

        if (!int.TryParse(parts[1], out int receivedPlayerId))
            return;

        if (receivedPlayerId == playerId)
            return;

        bool okX = float.TryParse(parts[2], NumberStyles.Float, CultureInfo.InvariantCulture, out float x);
        bool okY = float.TryParse(parts[3], NumberStyles.Float, CultureInfo.InvariantCulture, out float y);
        bool okZ = float.TryParse(parts[4], NumberStyles.Float, CultureInfo.InvariantCulture, out float z);
        bool okRot = float.TryParse(parts[5], NumberStyles.Float, CultureInfo.InvariantCulture, out float rotY);
        bool okSpeed = float.TryParse(parts[6], NumberStyles.Float, CultureInfo.InvariantCulture, out float speed);

        bool okRunning = int.TryParse(parts[7], out int runningValue);
        bool okCrouching = int.TryParse(parts[8], out int crouchingValue);

        if (!okX || !okY || !okZ || !okRot || !okSpeed || !okRunning || !okCrouching)
            return;

        targetRemotePosition = new Vector3(x, y, z);
        targetRemoteRotation = Quaternion.Euler(0f, rotY, 0f);

        targetRemoteSpeed = speed;
        targetRemoteIsRunning = runningValue == 1;
        targetRemoteIsCrouching = crouchingValue == 1;

        hasRemoteState = true;
    }

    void ProcessMonsterMovePacket(string[] parts, string packet)
    {
        if (parts.Length != 9)
        {
            Debug.LogWarning("MONSTER_MOVE ��Ŷ ������ ���� ����: " + packet);
            return;
        }

        if (!int.TryParse(parts[1], out int receivedMonsterId))
            return;

        bool okX = float.TryParse(parts[2], NumberStyles.Float, CultureInfo.InvariantCulture, out float x);
        bool okY = float.TryParse(parts[3], NumberStyles.Float, CultureInfo.InvariantCulture, out float y);
        bool okZ = float.TryParse(parts[4], NumberStyles.Float, CultureInfo.InvariantCulture, out float z);
        bool okRot = float.TryParse(parts[5], NumberStyles.Float, CultureInfo.InvariantCulture, out float rotY);
        bool okSpeed = float.TryParse(parts[6], NumberStyles.Float, CultureInfo.InvariantCulture, out float speed);

        bool okWalk = int.TryParse(parts[7], out int walkValue);
        bool okAttack = int.TryParse(parts[8], out int attackValue);

        if (!okX || !okY || !okZ || !okRot || !okSpeed || !okWalk || !okAttack)
            return;

        ApplyRemoteMonsterTransform(
            receivedMonsterId,
            new Vector3(x, y, z),
            Quaternion.Euler(0f, rotY, 0f),
            speed,
            walkValue == 1,
            attackValue == 1
        );
    }

    void ProcessPlayerDamagePacket(string[] parts, string packet)
    {
        if (parts.Length != 3)
        {
            Debug.LogWarning("PLAYER_DAMAGE ��Ŷ ������ ���� ����: " + packet);
            return;
        }

        if (!int.TryParse(parts[1], out int targetPlayerId))
            return;

        if (!int.TryParse(parts[2], out int damage))
            return;

        ApplyPlayerDamage(targetPlayerId, damage);
    }

    void ProcessItemPickupPacket(string[] parts, string packet)
    {
        if (parts.Length != 3)
        {
            Debug.LogWarning("ITEM_PICKUP ��Ŷ ������ ���� ����: " + packet);
            return;
        }

        if (!int.TryParse(parts[1], out int itemId))
            return;

        if (!int.TryParse(parts[2], out int pickedPlayerId))
            return;

        if (pickedPlayerId == playerId)
            return;

        if (potionItems == null || potionItems.Length == 0)
            potionItems = FindObjectsOfType<PotionItem>(true);

        foreach (PotionItem item in potionItems)
        {
            if (item == null)
                continue;

            if (item.itemId != itemId)
                continue;

            item.ApplyRemotePickup();
            Debug.Log("��� ������ ȹ�� �ݿ� �Ϸ� / itemId: " + itemId);
            return;
        }

        Debug.LogWarning("itemId�� �ش��ϴ� �������� ã�� ����: " + itemId);
    }

    void ApplyRemotePlayerTransform()
    {
        if (!hasRemoteState || remotePlayerTransform == null)
            return;

        RemotePlayer remotePlayer = remotePlayerTransform.GetComponent<RemotePlayer>();

        if (remotePlayer != null)
        {
            remotePlayer.SetState(targetRemotePosition, targetRemoteRotation);
            remotePlayer.SetAnimationState(
                targetRemoteSpeed,
                targetRemoteIsRunning,
                targetRemoteIsCrouching
            );
        }
        else
        {
            remotePlayerTransform.position = targetRemotePosition;
            remotePlayerTransform.rotation = targetRemoteRotation;
        }
    }

    void ApplyRemoteMonsterTransform(
        int monsterId,
        Vector3 position,
        Quaternion rotation,
        float speed,
        bool isWalk,
        bool isAttack
    )
    {
        if (playerId == 1)
            return;

        if (monsterSetups == null || monsterSetups.Length == 0)
            monsterSetups = FindObjectsOfType<MonsterNetworkSetup>();

        foreach (MonsterNetworkSetup monster in monsterSetups)
        {
            if (monster == null)
                continue;

            if (monster.monsterId != monsterId)
                continue;

            RemoteMonster remoteMonster = monster.GetComponent<RemoteMonster>();

            if (remoteMonster != null)
            {
                remoteMonster.SetState(position, rotation);
                remoteMonster.SetAnimationState(speed, isWalk, isAttack);
            }
            else
            {
                monster.transform.position = position;
                monster.transform.rotation = rotation;
            }

            return;
        }

        Debug.LogWarning("monsterId�� �ش��ϴ� ���͸� ã�� ����: " + monsterId);
    }

    void ApplyPlayerDamage(int targetPlayerId, int damage)
    {
        GameObject targetObject = null;

        if (targetPlayerId == 1)
            targetObject = player1Object;
        else if (targetPlayerId == 2)
            targetObject = player2Object;

        if (targetObject == null)
        {
            Debug.LogWarning("������ ���� ��� �÷��̾� ������Ʈ�� ã�� ����: " + targetPlayerId);
            return;
        }

        PlayerController playerController = targetObject.GetComponent<PlayerController>();

        if (playerController == null)
        {
            Debug.LogWarning("������ ���� ��� PlayerController�� ����: " + targetObject.name);
            return;
        }

        bool wasDead = playerController.IsDeadState;

        playerController.TakeDamage(damage);

        bool isDeadNow = playerController.IsDeadState;

        RemotePlayer remotePlayer = targetObject.GetComponent<RemotePlayer>();

        if (remotePlayer != null && !playerController.isLocalPlayer)
        {
            if (isDeadNow)
            {
                remotePlayer.PlayDeathAnimation();
            }
            else if (!wasDead)
            {
                remotePlayer.PlayHitAnimation();
            }
        }

        Debug.Log("PLAYER_DAMAGE ���� �Ϸ� / target: " + targetPlayerId + " / damage: " + damage);
    }

    void OnApplicationQuit()
    {
        if (stream != null)
            stream.Close();

        if (client != null)
            client.Close();
    }

    void LoadServerConfig()
    {
        string configPath = Path.Combine(Application.dataPath, "../server_config.txt");
        configPath = Path.GetFullPath(configPath);

        if (!File.Exists(configPath))
        {
            Debug.LogWarning("server_config.txt�� ã�� ���߽��ϴ�. Inspector �⺻�� ���: "
                + serverIP + ":" + serverPort + " / PlayerId: " + playerId);
            return;
        }

        string[] lines = File.ReadAllLines(configPath);

        foreach (string line in lines)
        {
            string trimmedLine = line.Trim();

            if (string.IsNullOrEmpty(trimmedLine))
                continue;

            if (trimmedLine.StartsWith("#"))
                continue;

            string[] parts = trimmedLine.Split('=');

            if (parts.Length != 2)
                continue;

            string key = parts[0].Trim();
            string value = parts[1].Trim();

            if (key == "SERVER_IP")
            {
                serverIP = value;
            }
            else if (key == "SERVER_PORT")
            {
                if (int.TryParse(value, out int parsedPort))
                {
                    serverPort = parsedPort;
                }
                else
                {
                    Debug.LogWarning("SERVER_PORT ���� �߸��Ǿ����ϴ�: " + value);
                }
            }
            else if (key == "PLAYER_ID")
            {
                if (int.TryParse(value, out int parsedPlayerId))
                {
                    playerId = parsedPlayerId;
                }
                else
                {
                    Debug.LogWarning("PLAYER_ID ���� �߸��Ǿ����ϴ�: " + value);
                }
            }
        }

        Debug.Log("Config ���� �Ϸ� / Server: " + serverIP + ":" + serverPort + " / PlayerId: " + playerId);
    }
}